// This function is available in admin-custom.js file. This function is also used in CodeStar icon picker developed by ThemeStek
tste_inducstco_icon_picker();
