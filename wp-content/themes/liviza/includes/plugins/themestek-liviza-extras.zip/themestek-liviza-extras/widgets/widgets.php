<?php

// List All Posts Widget
require THEMESTEK_LIVIZA_DIR . 'widgets/list-all-posts-widget.php';

// Contact Widget
require THEMESTEK_LIVIZA_DIR . 'widgets/contact-widget.php';

// Recent Posts Widget
require THEMESTEK_LIVIZA_DIR . 'widgets/recent-posts-widget.php';

// Flicker Widget
require THEMESTEK_LIVIZA_DIR . 'widgets/flicker-widget.php';

// Category/Group List Widget
require THEMESTEK_LIVIZA_DIR . 'widgets/category-list.php';